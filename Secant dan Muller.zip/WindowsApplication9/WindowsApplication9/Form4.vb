﻿Public Class Form4

    Dim i As Integer
    Dim j As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.Show()
        Timer1.Start()

        i = 6
        Timer1.Interval = 1000
        i -= 1
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        i -= 1
        If ProgressBar1.Value < 90 Then
            ProgressBar1.Value += 18
        Else
            ProgressBar1.Value += 9
        End If

        If (i = -1) Then
            Timer1.Stop()
            PictureBox1.Dispose()
            ProgressBar1.Dispose()
            Me.Hide()
            Form3.Show()

        End If

    End Sub

End Class