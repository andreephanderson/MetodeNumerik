﻿Imports System.Windows.Forms.DataVisualization.Charting
Public Class Form2
    Dim fungsix0 As Double
    Dim fungsix1 As Double
    Dim functionCounted As Boolean = False
    Dim nilaiKesalahan As Double = 1
    Dim iterasi As Integer = 0
    Dim buttonCount As Integer = 0
    Dim i As Integer
    Dim string1 As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
        buttonCount = 0
    End Sub



    Dim x0, x1, x2, x3 As Double

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        functionCounted = False
        Me.Dispose()
        Form3.Show()
    End Sub

    Function fungsiPolinomial1(ByVal x As Double) As Double
        Return (4 * Math.Sin(x)) - (Math.Pow(Math.E, x))
    End Function

    Function fungsiPolinomial2(ByVal x As Double) As Double
        Return ((x * (Math.Pow(Math.E, -x / 2))) - 0.5)
    End Function
    Function fungsiPolinomial3(ByVal x As Double) As Double
        Return (Math.Pow(x, 2) - (3 * x) - 4)
    End Function
    Function fungsiPolinomial4(ByVal x As Double) As Double
        Return (Math.Pow(x, 3) - (4 * (x * x)) + 4)
    End Function
    Function fungsiPolinomial5(ByVal x As Double) As Double
        Return (Math.Pow(x, 2) - (5 * x) - 6)
    End Function
    Function fungsiPolinomial6(ByVal x As Double) As Double
        Return (Math.Pow(x, 2) - 49)
    End Function
    Function fungsiPolinomial7(ByVal x As Double) As Double
        Return (2 * Math.Pow(x, 3) - Math.Pow(x, 2) - 10)
    End Function
    Function fungsiPolinomial8(ByVal x As Double) As Double
        Return (Math.Pow(x, 4) - (3 * Math.Pow(x, 3)) + Math.Pow(x, 2) - 6)
    End Function
    Function fungsiPolinomial9(ByVal x As Double) As Double
        Return (Math.Pow(x, 2) - (16 * x) + 63)
    End Function
    Function fungsiPolinomial10(ByVal x As Double) As Double
        Return (Math.Pow(x, 2) - (3 * x))
    End Function
    Function fungsiPolinomial11(ByVal x As Double) As Double
        Return (1 + (x - 2) * Math.Pow(Math.E, -1 * x))
    End Function
    Function fungsiPolinomial12(ByVal x As Double) As Double
        Return ((Math.Pow(x, 3)) - (15 * (x * x)) - (17 * x) + 6)
    End Function
    Function fungsiPolinomial13(ByVal x As Double) As Double
        Return (4 * Math.Pow(x, 2) - (7 * x) - 2)
    End Function
    Function fungsiPolinomial14(ByVal x As Double) As Double
        Return (Math.Pow(Math.E, 2 * x) + x + Math.Pow(x, 3))
    End Function

    Function fungsiPolinomial15(ByVal x As Double) As Double
        Return (Math.E * Math.Pow(x, 3) - Math.Pow((4 * x), 2) + 15)
    End Function
    Function fungsiPolinomial16(ByVal x As Double) As Double
        Return (2 * (Math.Pow(x, 3)) + (3 * (x * x)) - (7 * x) - 3)
    End Function

    Function fungsiPolinomial17(ByVal x As Double) As Double
        Return (Math.Pow(x, 3) - 27)
    End Function
    Function fungsiPolinomial18(ByVal x As Double) As Double
        Return (Math.Pow(Math.E, x) - (5 * x))
    End Function
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 0 Then
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "4 sin (x) - e^x"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial1(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 1
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x e ^ (-x / 2) - 0.5"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial2(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 2
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 3x - 4"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial3(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 3
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^3 - 4x^2 + 4"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial4(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 4
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 5x - 6"
            For i = -5 To 8
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial5(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 5
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 49"
            For i = 0 To 10
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial6(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 6
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "2x^3 – x^2 - 10"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial7(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 7
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^4 - 3x^3 + x^2 - 6"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial8(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 8
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 16x + 63"
            For i = 2 To 10
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial9(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 9
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 3x"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial10(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 10
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "1 + (x-2)e^(-x)"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial11(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 11
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^3 - 15 x^2 - 17x + 6"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial12(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 12
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "4x^2 – 7x – 2"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial13(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 13
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "e^(2x) + x + x^3"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial14(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 14
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "ex^3 - (4x)^2 + 15"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial15(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 15
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "2x^3 + 3 x^2 - 7x - 3"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial16(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 16
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^3 - 27"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial17(i))
            Next
        ElseIf ComboBox1.SelectedIndex = 17
            Me.Chart3.Series(0).Points.Clear()
            Chart3.Series(0).Name = "x^2 - 1"
            For i = -5 To 5
                Me.Chart3.Series(0).Points.AddXY(i, fungsiPolinomial18(i))
            Next
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Refresh()
        buttonCount += 1
        Try
            If TextBox3.Text < 0 Or TextBox3.Text > 100 Then
                MessageBox.Show("Nilai Toleransi error harus diantara 0 - 100 persen", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                buttonCount = 0
            Else
                If buttonCount = 1 Then
                    Try
                        x0 = TextBox1.Text
                        x1 = TextBox2.Text

                        If ComboBox1.SelectedIndex = 0 Then
                            fungsix0 = fungsiPolinomial1(x0)
                            fungsix1 = fungsiPolinomial1(x1)
                            Chart1.Series(0).Name = "4 sin (x) - e^x"
                            Chart2.Series(0).Name = "4 sin (x) - e^x"

                        ElseIf ComboBox1.SelectedIndex = 1 Then
                            fungsix0 = fungsiPolinomial2(x0)
                            fungsix1 = fungsiPolinomial2(x1)
                            Chart1.Series(0).Name = "x e ^ (-x / 2) - 0.5"
                            Chart2.Series(0).Name = "x e ^ (-x / 2) - 0.5"

                        ElseIf ComboBox1.SelectedIndex = 2 Then
                            fungsix0 = fungsiPolinomial3(x0)
                            fungsix1 = fungsiPolinomial3(x1)

                            Chart1.Series(0).Name = "x^2 - 3x - 4"
                            Chart2.Series(0).Name = "x^2 - 3x - 4"

                        ElseIf ComboBox1.SelectedIndex = 3 Then
                            fungsix0 = fungsiPolinomial4(x0)
                            fungsix1 = fungsiPolinomial4(x1)

                            Chart1.Series(0).Name = "x^3 - 4x^2 + 4"
                            Chart2.Series(0).Name = "x^3 - 4x^2 + 4"

                        ElseIf ComboBox1.SelectedIndex = 4 Then
                            fungsix0 = fungsiPolinomial5(x0)
                            fungsix1 = fungsiPolinomial5(x1)

                            Chart1.Series(0).Name = "x^2 - 5x - 6"
                            Chart2.Series(0).Name = "x^2 - 5x - 6"

                        ElseIf ComboBox1.SelectedIndex = 5 Then
                            fungsix0 = fungsiPolinomial6(x0)
                            fungsix1 = fungsiPolinomial6(x1)

                            Chart1.Series(0).Name = "x^2 - 49"
                            Chart2.Series(0).Name = "x^2 - 49"

                        ElseIf ComboBox1.SelectedIndex = 6 Then
                            fungsix0 = fungsiPolinomial7(x0)
                            fungsix1 = fungsiPolinomial7(x1)

                            Chart1.Series(0).Name = "2x^3 – x^2 - 10"
                            Chart2.Series(0).Name = "2x^3 – x^2 - 10"

                        ElseIf ComboBox1.SelectedIndex = 7 Then
                            fungsix0 = fungsiPolinomial8(x0)
                            fungsix1 = fungsiPolinomial8(x1)

                            Chart1.Series(0).Name = "x^4 - 3x^3 + x^2 - 6"
                            Chart2.Series(0).Name = "x^4 - 3x^3 + x^2 - 6"

                        ElseIf ComboBox1.SelectedIndex = 8 Then
                            fungsix0 = fungsiPolinomial9(x0)
                            fungsix1 = fungsiPolinomial9(x1)

                            Chart1.Series(0).Name = "x^2 - 16x + 63"
                            Chart2.Series(0).Name = "x^2 - 16x + 63"

                        ElseIf ComboBox1.SelectedIndex = 9 Then
                            fungsix0 = fungsiPolinomial10(x0)
                            fungsix1 = fungsiPolinomial10(x1)

                            Chart1.Series(0).Name = "x^2 - 3x"
                            Chart2.Series(0).Name = "x^2 - 3x"

                        ElseIf ComboBox1.SelectedIndex = 10 Then
                            fungsix0 = fungsiPolinomial11(x0)
                            fungsix1 = fungsiPolinomial11(x1)

                            Chart1.Series(0).Name = "1 + (x-2)e^(-x)"
                            Chart2.Series(0).Name = "1 + (x-2)e^(-x)"

                        ElseIf ComboBox1.SelectedIndex = 11 Then
                            fungsix0 = fungsiPolinomial12(x0)
                            fungsix1 = fungsiPolinomial12(x1)

                            Chart1.Series(0).Name = "x^3 - 15 x^2 - 17x + 6"
                            Chart2.Series(0).Name = "x^3 - 15 x^2 - 17x + 6"

                        ElseIf ComboBox1.SelectedIndex = 12 Then
                            fungsix0 = fungsiPolinomial13(x0)
                            fungsix1 = fungsiPolinomial13(x1)

                            Chart1.Series(0).Name = "4x^2 – 7x – 2"
                            Chart2.Series(0).Name = "4x^2 – 7x – 2"

                        ElseIf ComboBox1.SelectedIndex = 13 Then
                            fungsix0 = fungsiPolinomial14(x0)
                            fungsix1 = fungsiPolinomial14(x1)

                            Chart1.Series(0).Name = "e^(2x) + x + x^3"
                            Chart2.Series(0).Name = "e^(2x) + x + x^3"

                        ElseIf ComboBox1.SelectedIndex = 14 Then
                            fungsix0 = fungsiPolinomial15(x0)
                            fungsix1 = fungsiPolinomial15(x1)

                            Chart1.Series(0).Name = "ex^3 - (4x)^2 + 15"
                            Chart2.Series(0).Name = "ex^3 - (4x)^2 + 15"

                        ElseIf ComboBox1.SelectedIndex = 15 Then
                            fungsix0 = fungsiPolinomial16(x0)
                            fungsix1 = fungsiPolinomial16(x1)

                            Chart1.Series(0).Name = "2 x^3 + 3 x^2 - 7x - 3"
                            Chart2.Series(0).Name = "2 x^3 + 3 x^2 - 7x - 3"

                        ElseIf ComboBox1.SelectedIndex = 16 Then
                            fungsix0 = fungsiPolinomial17(x0)
                            fungsix1 = fungsiPolinomial17(x1)

                            Chart1.Series(0).Name = "x^3 - 27"
                            Chart2.Series(0).Name = "x^3 - 27"

                        ElseIf ComboBox1.SelectedIndex = 17 Then
                            fungsix0 = fungsiPolinomial18(x0)

                            fungsix1 = fungsiPolinomial18(x1)

                            Chart1.Series(0).Name = "x^2 - 1"
                            Chart2.Series(0).Name = "x^2 - 1"

                        End If

                x2 = x1 - ((fungsix1 * (x0 - x1)) / (fungsix0 - fungsix1))

                        x0 = x1
                        x1 = x2

                        While (nilaiKesalahan > TextBox3.Text)
                            If ComboBox1.SelectedIndex = 0 Then
                                fungsix0 = fungsiPolinomial1(x0)
                                fungsix1 = fungsiPolinomial1(x1)
                            ElseIf ComboBox1.SelectedIndex = 1 Then
                                fungsix0 = fungsiPolinomial2(x0)
                                fungsix1 = fungsiPolinomial2(x1)
                            ElseIf ComboBox1.SelectedIndex = 2 Then
                                fungsix0 = fungsiPolinomial3(x0)
                                fungsix1 = fungsiPolinomial3(x1)
                            ElseIf ComboBox1.SelectedIndex = 3 Then
                                fungsix0 = fungsiPolinomial4(x0)
                                fungsix1 = fungsiPolinomial4(x1)
                            ElseIf ComboBox1.SelectedIndex = 4 Then
                                fungsix0 = fungsiPolinomial5(x0)
                                fungsix1 = fungsiPolinomial5(x1)
                            ElseIf ComboBox1.SelectedIndex = 5 Then
                                fungsix0 = fungsiPolinomial6(x0)
                                fungsix1 = fungsiPolinomial6(x1)
                            ElseIf ComboBox1.SelectedIndex = 6 Then
                                fungsix0 = fungsiPolinomial7(x0)
                                fungsix1 = fungsiPolinomial7(x1)
                            ElseIf ComboBox1.SelectedIndex = 7 Then
                                fungsix0 = fungsiPolinomial8(x0)
                                fungsix1 = fungsiPolinomial8(x1)
                            ElseIf ComboBox1.SelectedIndex = 8 Then
                                fungsix0 = fungsiPolinomial9(x0)
                                fungsix1 = fungsiPolinomial9(x1)
                            ElseIf ComboBox1.SelectedIndex = 9 Then
                                fungsix0 = fungsiPolinomial10(x0)
                                fungsix1 = fungsiPolinomial10(x1)
                            ElseIf ComboBox1.SelectedIndex = 10 Then
                                fungsix0 = fungsiPolinomial11(x0)
                                fungsix1 = fungsiPolinomial11(x1)
                            ElseIf ComboBox1.SelectedIndex = 11 Then
                                fungsix0 = fungsiPolinomial12(x0)
                                fungsix1 = fungsiPolinomial12(x1)
                            ElseIf ComboBox1.SelectedIndex = 12 Then
                                fungsix0 = fungsiPolinomial13(x0)
                                fungsix1 = fungsiPolinomial13(x1)
                            ElseIf ComboBox1.SelectedIndex = 13 Then
                                fungsix0 = fungsiPolinomial14(x0)
                                fungsix1 = fungsiPolinomial14(x1)
                            ElseIf ComboBox1.SelectedIndex = 14 Then
                                fungsix0 = fungsiPolinomial15(x0)
                                fungsix1 = fungsiPolinomial15(x1)
                            ElseIf ComboBox1.SelectedIndex = 15 Then
                                fungsix0 = fungsiPolinomial16(x0)
                                fungsix1 = fungsiPolinomial16(x1)
                            ElseIf ComboBox1.SelectedIndex = 16 Then
                                fungsix0 = fungsiPolinomial17(x0)
                                fungsix1 = fungsiPolinomial17(x1)
                            ElseIf ComboBox1.SelectedIndex = 17 Then
                                fungsix0 = fungsiPolinomial18(x0)
                                fungsix1 = fungsiPolinomial18(x1)
                            End If

                            x2 = x1 - ((fungsix1 * (x0 - x1)) / (fungsix0 - fungsix1))
                            nilaiKesalahan = ((x2 - x1) / x2) * 100
                            If (nilaiKesalahan < 0) Then
                                nilaiKesalahan = nilaiKesalahan * (-1)
                            End If
                            x0 = x1
                            x1 = x2

                            Me.Chart2.Series(0).Points.Add(nilaiKesalahan)
                            Me.Chart1.Series(0).Points.Add(x2)

                            string1 += "Akar = " + CStr(x2) + " dengan error sebesar " + CStr(nilaiKesalahan) + " %" + vbCrLf
                            iterasi += 1

                        End While

                        TextBox7.Text = nilaiKesalahan
                        TextBox4.Text = x2
                        TextBox5.Text = iterasi
                        TextBox6.Text = string1
                        'MessageBox.Show(string1)

                    Catch ex As Exception
                        MessageBox.Show("Pastikan anda masukkan angka !")
                        buttonCount = 0
                    End Try
                Else
                    MessageBox.Show("Untuk melihat grafik dengan soal berbeda, anda harus menutup dan membuka kembali form ini", "Notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("Pastikan anda memasukkan angka!", "Notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
        End Try

    End Sub



End Class
