﻿Imports System.Windows.Forms.DataVisualization.Charting

Public Class Form5
    Dim s As New Series
    Function f(ByVal x)
        Dim z As Double
        z = x * x + x * 3 + 5
        Return z
    End Function

    Sub DoChart()
        Dim h As Double
        Dim y As Double
        Dim x As Double
        x = 0
        h = 0.04
        s.Name = "Yoko"
        s.ChartType = SeriesChartType.Line

        For index As Integer = 0 To 100
            y = f(x)
            s.Points.AddXY(x, y)
            x = x + h
        Next
        s.IsXValueIndexed = True
        Chart1.Series.Add(s)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DoChart()
    End Sub
End Class
